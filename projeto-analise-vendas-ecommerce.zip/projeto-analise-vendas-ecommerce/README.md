
# 📊 Projeto de Análise de Vendas – Loja de E-commerce

## 🔍 Sobre o projeto
Este projeto simula a análise de vendas de uma loja de e-commerce. O objetivo é gerar insights de negócio a partir dos dados utilizando **Python (Google Colab)** para análise exploratória e **Power BI** para visualização e construção de um dashboard interativo.

## 📦 Dataset
- Dados fictícios gerados para fins educacionais
- Contém informações sobre:
  - Pedidos
  - Produtos
  - Categorias
  - Quantidade
  - Receita
  - Localização (Estado)

## 🎯 O que foi desenvolvido
- 📊 **Análise exploratória no Python (Google Colab):**
  - Limpeza dos dados
  - Cálculo da receita
  - KPIs de vendas
  - Gráficos exploratórios (barras, linhas, pizza)

- 📈 **Dashboard no Power BI:**
  - Receita total
  - Total de pedidos
  - Total de clientes
  - Quantidade total de produtos vendidos
  - Top 10 produtos mais vendidos
  - Receita por categoria
  - Receita por estado (com mapa)
  - Evolução da receita por mês (sazonalidade)
  - Filtro dinâmico por estado

## 🛠️ Ferramentas utilizadas
- Python (Google Colab)
  - Pandas
  - Matplotlib
  - Seaborn
- Power BI

## 💡 Principais insights
- 📊 **Eletrônicos e Moda** são as categorias com maior faturamento
- 🏆 Top 10 produtos representam boa parte das vendas
- 🗺️ **SP, RJ e MG** são os estados que mais concentram receita
- 📅 Existe sazonalidade nas vendas, observada na evolução mensal

## 🚀 Como executar
1. Clone este repositório
2. Acesse o notebook `analise_exploratoria.ipynb` no Google Colab ou Jupyter
3. Abra o arquivo `dashboard_ecommerce.pbix` no Power BI Desktop
4. Explore os gráficos, filtros e KPIs

## 📁 Estrutura do repositório
```
📦 projeto-analise-vendas-ecommerce
 ┣ 📂 dataset
 ┃ ┗ 📄 ecommerce_loja.csv
 ┣ 📂 dashboard
 ┃ ┗ 📄 dashboard_vendas.pbix
 ┣ 📂 notebooks
 ┃ ┗ 📄 analise_exploratoria.ipynb
 ┣ 📄 README.md
```

## 🤝 Contribuição
Sinta-se à vontade para sugerir melhorias, abrir issues ou contribuir!

## 🧠 Autor
- [Seu Nome](https://www.linkedin.com/in/seuusuario) | [GitHub](https://github.com/seuusuario)
